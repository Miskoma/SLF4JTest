package test;

import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.ThreadContext;

@Log4j2
public class Logger2  extends Thread {
    public static void logSomething(){
        log.error("error_something");
    }

    public void run(){
        log();
    }

    public void log() {
        ThreadContext
        ThreadContext.put("threadId", Thread.currentThread().getName());;
        System.out.println(Thread.currentThread().getName());
        log.error("error thread");
    }

}
