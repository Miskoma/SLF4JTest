package test;

import lombok.extern.log4j.Log4j2;
import org.apache.logging.log4j.ThreadContext;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//@SpringBootApplication
@Log4j2
public class LoggerTest extends Thread implements CommandLineRunner {


    public static void main(String[] args) throws Exception {
        ThreadContext.put("threadId", "main"); // Add the fishtag;
//        SpringApplication.run(LoggerTest.class, args);
        new LoggerTest().run(args);
    }

    @Override
    public void run(String... args) throws Exception {
        ThreadContext.put("threadId", "main"); // Add the fishtag;


        log.error("error");
        log.warn("warn");
        log.info("info");
        log.debug("debug");
        log.trace("trace");
        System.out.println();

        ThreadContext.put("threadId", "thread2"); // Add the fishtag;

        log.error("error2");
        log.warn("warn2");
        log.info("info2");
        log.debug("debug2");
        log.trace("trace2");

        ThreadContext.put("threadId", "thread3"); // Add the fishtag;
Logger2 l2 = new Logger2();
l2.start();

        log.error("error3");
        log.warn("warn3");
        log.info("info3");
        log.debug("debug3");
        log.trace("trace3");

        ThreadContext.clearAll();
        System.out.println(Thread.currentThread().getName());
    }
}
